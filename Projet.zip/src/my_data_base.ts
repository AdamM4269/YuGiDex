export default async function initClient2() {
  const app = document.getElementById('app');
  if (!app) return;

  app.innerHTML = `<h1>Client 2</h1><p>Chargement des données...</p>`;

  try {
    const response = await fetch('/api/data');
    const data = await response.json();

    if (!Array.isArray(data)) {
      app.innerHTML = `<p>Erreur: données invalides</p>`;
      return;
    }

    const table = document.createElement('table');
    table.border = '1';
    const header = document.createElement('tr');
    Object.keys(data[0] || {}).forEach(key => {
      const th = document.createElement('th');
      th.textContent = key;
      header.appendChild(th);
    });
    table.appendChild(header);

    data.forEach(row => {
      const tr = document.createElement('tr');
      Object.values(row).forEach(value => {
        const td = document.createElement('td');
        td.textContent = String(value);
        tr.appendChild(td);
      });
      table.appendChild(tr);
    });

    app.innerHTML = `<h1>Client 2</h1>`;
    app.appendChild(table);
  } catch (error) {
    app.innerHTML = `<p>Erreur lors du chargement : ${error}</p>`;
  }
}